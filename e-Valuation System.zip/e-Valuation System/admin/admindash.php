<?php
session_start();

if (isset($_SESSION['uid'])) {
    echo "";
} else {
    header('location:adminlogin.php');
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="adminstyle.css" type="text/css">
    <link href="https://fonts.googleapis.com/css2?family=Acme&family=Fredoka+One&family=Patua+One&family=Righteous&display=swap" rel="stylesheet">
    <title>Admin Control Panel</title>
</head>

<body>
    <div class="cplogout">
        <a href="adminlogout.php">logout</a>
    </div>
    <div class="cpheading">
        Admin Control Panel
    </div>
    
    <div class="teacher-field">
        <div class="teacher-heading">Teachers</div>
        <div class="teacher-content">
            <div class="addTeacher tech">
                <a href="addteacher.php">Add Teacher</a>
            </div>
            <div class="updateTeacher tech">
                <a href="updateteacher.php">Update Teacher</a>
            </div>
            <div class="deleteTeacher tech">
                <a href="deleteteacher.php">Delete Teacher</a>
            </div>
            <div class="displayTeacher tech">
                <a href="displayteacher.php">Display Teachers</a>
            </div>
        </div>
    </div>
    <div class="teacher-field">
        <div class="teacher-heading">Students</div>
        <div class="teacher-content">
            <div class="addTeacher tech">
                <a href="addstudent.php">Add Student</a>
            </div>
            <div class="updateTeacher tech">
                <a href="updatestudent.php">Update Student</a>
            </div>
            <div class="deleteTeacher tech">
                <a href="deletestudent.php">Delete Student</a>
            </div>
            <div class="displayTeacher tech">
                <a href="displaystudent.php">Display Students</a>
            </div>
        </div>
    </div>
    <div class="file-upload">
        <a href="sendfile.php">Upload Files</a>
    </div>
</body>

</html>