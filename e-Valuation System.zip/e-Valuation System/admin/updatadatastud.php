<?php
include('../dbcon.php');

$name = strtolower($_POST['name']);
$rollno = $_POST['roll'];
$class = $_POST['class'];
$mobile = $_POST['contact'];
$city = strtolower($_POST['city']);
$id  = $_POST['sid'];
$imagename = $_FILES['img']['name'];
$tempname = $_FILES['img']['tmp_name'];


move_uploaded_file($tempname, "../dataimg/student/$imagename");

$qry = "UPDATE `student` SET `name`='$name',`class`='$class',`image`='$imagename',`city`='$city',`contact`='$mobile',`rollno`='$rollno' WHERE `studentid` = '$id'";

$run = mysqli_query($con, $qry);

if ($run == True) {
?>

    <script>
        alert("Data Updated successfully");
        window.open('updatestudent.php?sid=<?php echo $id; ?>', '_self');
    </script>


<?php
} else {
    echo "Error: " . $run . "<br>" . mysqli_error($con);
}

?>