
<?php
session_start();

if (isset($_SESSION['uid'])) {
    echo "";
} else {
    header('location:adminlogin.php');
}
global $data;
?>
<?php
include('../dbcon.php');
?>
<html>

<head>
    <title>ADMIN|Send Files</title>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">

    <link rel="stylesheet" href="sendfile.css" type="text/css">
    <link href="https://fonts.googleapis.com/css2?family=Acme&family=Fredoka+One&family=Patua+One&family=Righteous&display=swap" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
</head>

<body>
    
    <div class="backtodash" style="font-size:18px;
        font-weight:bolder;
        font-family:'Righteous',cursive;
        background-color:#f29f3d;
        width:100px;
        text-align:center;"><a href="admindash.php" style="text-decoration: none;color:white;"> Dashboard</a></div>
    <div class="cplogout">
        <a href="adminlogout.php">logout</a>
    </div>
    <div class="cpheading">
        Admin Control Panel
    </div>
    <div class="page-heading">
        Send Files
    </div>
    <!-- SELECT SUBJECT -->
    <div class="selectionsub">
        <form method="post" action="sendfile.php">
            <span class="sub-ject"><input type="submit" value="hindi" name="hindi" class="button-sub"></span>
            <span class="sub-ject"><input type="submit" value="english" name="english" class="button-sub"></span>
            <span class="sub-ject"><input type="submit" value="math" name="math" class="button-sub"></span>
            <span class="sub-ject"><input type="submit" value="physics" name="physics" class="button-sub"></span>
            <span class="sub-ject"><input type="submit" value="chemistry" name="chemistry" class="button-sub"></span>

        </form>
    </div>
    <!-- Selection of Subject end here-->
    <form action="sendfile.php" method="post">
        <table class="displaytable" width="45%" style="margin-top:20px;">
            <tr style="background-color:#324e7b; color:white; font-size:18px; ">
                <th>No.</th>
                <th>Teacher-Id</th>
                <th>Teacher-Name</th>
                <th>Subject</th>
                <th>Select</th>
            </tr>
            <tr>
            <td>
                <?php

                if (isset($_POST['hindi'])) {
                    include('../dbcon.php');
                    $subject = 'hindi';
                    $qry = "SELECT `teacherid`, `teachername`, `subject` FROM `teacher` WHERE `subject` = '$subject'";
                    $run = mysqli_query($con, $qry);
                    if (mysqli_num_rows($run) < 1) {
                        echo "<tr><td colspan = '4'>No record Found</td></tr>";
                    } else {
                        $count = 0;
                        while ($data = mysqli_fetch_assoc($run)) {
                            $count++;
                ?>

                            <tr class="tablestyle">
                                <td><?php echo $count ?></td>
                                <td><?php echo $data['teacherid']; ?></td>
                                <td><?php echo $data['teachername']; ?></td>
                                <td><?php echo $data['subject']; ?></td>
                                <td>

                                    <input type="radio" name="teacher" value="<?php echo $data['teacherid']; ?>">

                                </td>

                            </tr>


                <?php

                        }
                    }
                }
                ?>
            </td>
            <td>
                <?php

                if (isset($_POST['english'])) {
                    include('../dbcon.php');
                    $subject = 'english';
                    $qry = "SELECT `teacherid`, `teachername`, `subject` FROM `teacher` WHERE `subject` = '$subject'";
                    $run = mysqli_query($con, $qry);
                    if (mysqli_num_rows($run) < 1) {
                        echo "<tr><td colspan = '4'>No record Found</td></tr>";
                    } else {
                        $count = 0;
                        while ($data = mysqli_fetch_assoc($run)) {
                            $count++;
                ?>
                            <tr class="tablestyle">
                                <td><?php echo $count ?></td>
                                <td><?php echo $data['teacherid']; ?></td>
                                <td><?php echo $data['teachername']; ?></td>
                                <td><?php echo $data['subject']; ?></td>
                                <td>

                                    <input type="radio" name="teacher" value="<?php echo $data['teacherid'] ?>">

                                </td>
                            </tr>
                <?php

                        }
                    }
                }
                ?>
            </td>
            <td>
                <?php

                if (isset($_POST['math'])) {
                    include('../dbcon.php');
                    $subject = 'math';
                    $qry = "SELECT `teacherid`, `teachername`, `subject` FROM `teacher` WHERE `subject` = '$subject'";
                    $run = mysqli_query($con, $qry);
                    if (mysqli_num_rows($run) < 1) {
                        echo "<tr><td colspan = '4'>No record Found</td></tr>";
                    } else {
                        $count = 0;
                        while ($data = mysqli_fetch_assoc($run)) {
                            $count++;
                ?>
                            <tr class="tablestyle">
                                <td><?php echo $count ?></td>
                                <td><?php echo $data['teacherid']; ?></td>
                                <td><?php echo $data['teachername']; ?></td>
                                <td><?php echo $data['subject']; ?></td>
                                <td>

                                    <input type="radio" name="teacher" value="<?php echo $data['teacherid'] ?>">

                                </td>
                            </tr>
                <?php

                        }
                    }
                }
                ?>
            </td>
            <td>
                <?php

                if (isset($_POST['physics'])) {
                    include('../dbcon.php');
                    $subject = 'physics';
                    $qry = "SELECT `teacherid`, `teachername`, `subject` FROM `teacher` WHERE `subject` = '$subject'";
                    $run = mysqli_query($con, $qry);
                    if (mysqli_num_rows($run) < 1) {
                        echo "<tr><td colspan = '4'>No record Found</td></tr>";
                    } else {
                        $count = 0;
                        while ($data = mysqli_fetch_assoc($run)) {
                            $count++;
                ?>
                            <tr class="tablestyle">
                                <td><?php echo $count ?></td>
                                <td><?php echo $data['teacherid']; ?></td>
                                <td><?php echo $data['teachername']; ?></td>
                                <td><?php echo $data['subject']; ?></td>
                                <td>

                                    <input type="radio" name="teacher" value="<?php echo $data['teacherid'] ?>">

                                </td>
                            </tr>
                <?php

                        }
                    }
                }
                ?>
            </td>
            <td>
                <?php

                if (isset($_POST['chemistry'])) {
                    include('../dbcon.php');
                    $subject = 'chemistry';
                    $qry = "SELECT `teacherid`, `teachername`, `subject` FROM `teacher` WHERE `subject` = '$subject'";
                    $run = mysqli_query($con, $qry);
                    if (mysqli_num_rows($run) < 1) {
                        echo "<tr><td colspan = '4'>No record Found</td></tr>";
                    } else {
                        $count = 0;
                        while ($data = mysqli_fetch_assoc($run)) {
                            $count++;
                ?>
                            <tr class="tablestyle">
                                <td><?php echo $count ?></td>
                                <td><?php echo $data['teacherid']; ?></td>
                                <td><?php echo $data['teachername']; ?></td>
                                <td><?php echo $data['subject']; ?></td>
                                <td>

                                    <input type="radio" name="teacher" value="<?php echo $data['teacherid'] ?>">

                                </td>
                            </tr>
                <?php

                        }
                    }
                }
                ?>
            </td>
            </tr>
        </table>
        <table class="displaytable" width="45%" style="margin-top:20px;position:relative;">
            <tr style="background-color:#324e7b; color:white; font-size:18px; ">
                <th>No.</th>
                <th>File Name</th>
                <th>Student Id</th>
                <th>Select</th>
            </tr>
            <tr>
                <td>
                    <?php
                         if (isset($_POST['hindi'])) {
                            include('../dbcon.php');
                            $subject = 'hindi';
                            $qry = "SELECT `studentid`,  `hindi` FROM `student` ";
                            $run = mysqli_query($con, $qry);
                            if (mysqli_num_rows($run) < 1) {
                                echo "<tr><td colspan = '4'>No record Found</td></tr>";
                            } else {
                                $count = 0;
                                while ($data = mysqli_fetch_assoc($run)) {
                                    $count++;
                    ?>
                    <tr class="tablestyle">
                                <td><?php echo $count ?></td>
                                <td><?php echo $data['hindi']; ?></td>
                                <td><?php echo $data['studentid']; ?></td>
                                
                                <td>

                                    <input type="checkbox" name="copy[]" value="<?php echo $data['studentid'] ?>" class="checkAll">
                                    <input type="checkbox" name="cpy[]" value="<?php echo $data['hindi']?>" class="check" style="visibility: hidden;display:none;">
                                    <script>
                                        $(".checkAll").on("change",function(){
                                         if($(this).is(":checked")) 
                                        $(this).closest("tr").find(".check").prop('checked',true);
                                        else
                                         $(this).closest("tr").find(".check").prop('checked',false);

                                        });
                                    </script>
                                </td>
                            </tr>
                <?php

                        }
                    }
                }
                ?>
                </td>
                <td>
                    <?php
                         if (isset($_POST['english'])) {
                            include('../dbcon.php');
                            $subject = 'english';
                            $qry = "SELECT `studentid`,  `english` FROM `student` ";
                            $run = mysqli_query($con, $qry);
                            if (mysqli_num_rows($run) < 1) {
                                echo "<tr><td colspan = '4'>No record Found</td></tr>";
                            } else {
                                $count = 0;
                                while ($data = mysqli_fetch_assoc($run)) {
                                    $count++;
                    ?>
                    <tr class="tablestyle">
                                <td><?php echo $count ?></td>
                                <td><?php echo $data['english']; ?></td>
                                <td><?php echo $data['studentid']; ?></td>
                                
                                <td>

                                    <input type="checkbox" name="copy[]" value="<?php echo $data['studentid'] ?>" class="checkAll">
                                    <input type="checkbox" name="cpy[]" value="<?php echo $data['english']?>" class="check" style="visibility: hidden;display:none;">
                                    <script>  
                                        $(".checkAll").on("change",function(){
                                         if($(this).is(":checked")) 
                                        $(this).closest("tr").find(".check").prop('checked',true);
                                        else
                                         $(this).closest("tr").find(".check").prop('checked',false);

                                        });
                                    </script>
                                </td>
                            </tr>
                <?php

                        }
                    }
                }
                ?>
                </td>
                <td>
                    <?php
                         if (isset($_POST['math'])) {
                            include('../dbcon.php');
                            $subject = 'math';
                            $qry = "SELECT `studentid`,  `math` FROM `student` ";
                            $run = mysqli_query($con, $qry);
                            if (mysqli_num_rows($run) < 1) {
                                echo "<tr><td colspan = '4'>No record Found</td></tr>";
                            } else {
                                $count = 0;
                                while ($data = mysqli_fetch_assoc($run)) {
                                    $count++;
                    ?>
                    <tr class="tablestyle">
                                <td><?php echo $count ?></td>
                                <td><?php echo $data['math']; ?></td>
                                <td><?php echo $data['studentid']; ?></td>
                                
                                <td>

                                    <input type="checkbox" name="copy[]" value="<?php echo $data['studentid'] ?>" class="checkAll">
                                    <input type="checkbox" name="cpy[]" value="<?php echo $data['math']?>" class="check" style="visibility: hidden;display:none;">
                                    <script>
                                        $(".checkAll").on("change",function(){
                                         if($(this).is(":checked")) 
                                        $(this).closest("tr").find(".check").prop('checked',true);
                                        else
                                         $(this).closest("tr").find(".check").prop('checked',false);

                                        });
                                    </script>

                                </td>
                            </tr>
                <?php

                        }
                    }
                }
                ?>
                </td>
                <td>
                    <?php
                         if (isset($_POST['physics'])) {
                            include('../dbcon.php');
                            $subject = 'physics';
                            $qry = "SELECT `studentid`,  `physics` FROM `student` ";
                            $run = mysqli_query($con, $qry);
                            if (mysqli_num_rows($run) < 1) {
                                echo "<tr><td colspan = '4'>No record Found</td></tr>";
                            } else {
                                $count = 0;
                                while ($data = mysqli_fetch_assoc($run)) {
                                    $count++;
                    ?>
                    <tr class="tablestyle">
                                <td><?php echo $count ?></td>
                                <td><?php echo $data['physics']; ?></td>
                                <td><?php echo $data['studentid']; ?></td>
                                
                                <td>

                                    <input type="checkbox" name="copy[]" value="<?php echo $data['studentid'] ?>" class="checkAll">
                                    <input type="checkbox" name="cpy[]" value="<?php echo $data['physics']?>" class="check" style="visibility: hidden;display:none;">
                                    <script>
                                        $(".checkAll").on("change",function(){
                                         if($(this).is(":checked")) 
                                        $(this).closest("tr").find(".check").prop('checked',true);
                                        else
                                         $(this).closest("tr").find(".check").prop('checked',false);

                                        });
                                    </script>
                                </td>
                            </tr>
                <?php

                        }
                    }
                }
                ?>
                </td>
                <td>
                    <?php
                        
                         if (isset($_POST['chemistry'])) {
                            include('../dbcon.php');
                            $subject = 'chemistry';
                           
                            $qry = "SELECT `studentid`,  `chemistry` FROM `student` ";
                            
                            $run = mysqli_query($con, $qry);
                            if (mysqli_num_rows($run) < 1) {
                                echo "<tr><td colspan = '4'>No record Found</td></tr>";
                            } else {
                                $count = 0;
                                while ($data = mysqli_fetch_assoc($run)) {
                                    $count++;
                    ?>
                    <tr class="tablestyle">
                                <td><?php echo $count ?></td>
                                <td><?php echo $data['chemistry']; ?></td>
                                <td><?php echo $data['studentid']; ?></td>
                                
                                <td>

                                    <input type="checkbox" name="copy[]" value="<?php echo $data['studentid'] ?>" class="checkAll"> 
                                    <input type="checkbox" name="cpy[]" value="<?php echo $data['chemistry']?>" class="check" style="visibility: hidden;display:none;">
                                    <script>
                                        $(".checkAll").on("change",function(){
                                         if($(this).is(":checked")) 
                                        $(this).closest("tr").find(".check").prop('checked',true);
                                        else
                                         $(this).closest("tr").find(".check").prop('checked',false);

                                        });
                                    </script>
                                </td>
                            </tr>
                            
                
                        <?php
                        
                        }
                    }
                }
               
                
                ?>
                    </td>
                </tr>
            <input type="submit" value="Send-Data" name="senddata" style="float: right;width: 300px;height: 40px;background-color: #65aa45;border-radius: 20px;cursor:pointer;margin-top:200px;position:relative;"/>
        </form>
    </body>


</html>
<?php
    
    if(isset($_POST['senddata'])){
        include('../dbcon.php');
       
        $valofradio = $_POST['teacher'];
        $checkbox_val = $_POST['copy'];
        $checkbox_val_two = $_POST['cpy'];
       for($i=0;$i<count($checkbox_val);$i++){
        $checkvalue = $checkbox_val[$i];
        $checkboxvaluetwo = $checkbox_val_two[$i];
        $query1 = "INSERT INTO `files` (`studentid`, `teacherid`,`filename`)  VALUES ('$checkvalue','$valofradio','$checkboxvaluetwo')";
        
        $tof = mysqli_query($con,$query1);
       }
        if($tof ==1){
            echo '<script>alert("Data inserted successfully ");</script>';
            
            
        }
        else{
            echo '<script>alert("Data does not inserted successfully: Already In DB or Some Data not Selected")</script>';
        }
    }

?>

