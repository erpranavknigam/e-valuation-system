<?php
session_start();

if (isset($_SESSION['uid'])) {
    echo "";
} else {
    header('location:adminlogin.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="adminstyle.css" type="text/css">
    <link href="https://fonts.googleapis.com/css2?family=Acme&family=Fredoka+One&family=Patua+One&family=Righteous&display=swap" rel="stylesheet">
    <title>Admin|Update Student</title>
</head>

<body>
    <div class="backtodash" style="font-size:18px;
    font-weight:bolder;
    font-family:'Righteous',cursive;
    background-color:#f29f3d;
    width:100px;
    text-align:center;"><a href="admindash.php" style="text-decoration: none;color:white;"> Dashboard</a></div>
    <div class="cplogout">
        <a href="adminlogout.php">logout</a>
    </div>
    <div class="cpheading">
        Admin Control Panel
    </div>
    <div class="page-heading">
        Update Students
    </div>
    <div class="form-panel">
        <form action="updatestudent.php" method="post" enctype="multipart/form-data">
            <table>
                <tr>
                    <td class="label">Student Name:</td>
                    <td><input type="text" name="name" class="inp" placeholder="Enter Full Name" required /></td>
                </tr>
                <tr class="label">
                    <td>Class:</td>
                    <td><input type="number" name="class" class="inp" placeholder="Enter Class" required /></td>
                </tr>
                <tr>
                    <td><input type="submit" value="Search" name="submit" class="button"></td>
                    <td><input type="reset" value="Reset" name="reset" class="button"></td>
                </tr>
            </table>
        </form>
    </div>

    <table class="displaytable" width="80%" align="center" style="margin-top:20px;">
        <tr style="background-color:#324e7b; color:white; font-size:18px; ">
            <th>No.</th>
            <th>Image</th>
            <th>Name</th>
            <th>Roll No</th>
            <th>Student Id</th>
            <th>City</th>
            <th>Contact</th>
            <th>Edit</th>
        </tr>
        <td>
            <?php
            if (isset($_POST['submit'])) {
                include('../dbcon.php');

                $standard = $_POST['class'];
                $name = strtolower($_POST['name']);
                $sql = "SELECT * FROM `student` WHERE `name` LIKE LOWER('%$name%') AND `class` = '$standard'";
                $run = mysqli_query($con, $sql);

                if (mysqli_num_rows($run) < 1) {
                    echo "<tr><td colspan = '8'>No record Found</td></tr>";
                } else {
                    $count = 0;
                    while ($data = mysqli_fetch_assoc($run)) {
                        $count++;
            ?>
                        <tr class="tableStyle">
                            <td><?php echo $count; ?></td>
                            <td class="setImg"><img src="../dataimg/student/<?php echo $data['image']; ?>" style="max-width: 100px;" /></td>
                            <td><?php echo $data['name']; ?></td>
                            <td><?php echo $data['rollno']; ?></td>
                            <td><?php echo $data['studentid']; ?></td>
                            <td><?php echo $data['city']; ?></td>
                            <td><?php echo $data['contact']; ?></td>
                            <td><a href="updateformstud.php?sid=<?php echo $data['studentid']; ?>">Edit</a></td>
                        </tr>
            <?php
                    }
                }
            }
            ?>
        </td>
</body>

</html>