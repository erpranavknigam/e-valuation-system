<?php
session_start();

if (isset($_SESSION['uid'])) {
    echo "";
} else {
    header('location:adminlogin.php');
}
?>
<?php
include('../dbcon.php');

$studid = $_GET['sid'];
$sql = "SELECT * FROM `student` WHERE `studentid` = '$studid'";
$run = mysqli_query($con, $sql);

$data = mysqli_fetch_assoc($run);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="adminstyle.css" type="text/css">
    <link href="https://fonts.googleapis.com/css2?family=Acme&family=Fredoka+One&family=Patua+One&family=Righteous&display=swap" rel="stylesheet">
    <title>Admin|Update Student</title>
</head>

<body>
    <div class="backtodash" style="font-size:18px;
    font-weight:bolder;
    font-family:'Righteous',cursive;
    background-color:#f29f3d;
    width:100px;
    text-align:center;"><a href="admindash.php" style="text-decoration: none;color:white;"> Dashboard</a></div>
    <div class="cplogout">
        <a href="adminlogout.php">logout</a>
    </div>
    <div class="cpheading">
        Admin Control Panel
    </div>
    <div class="page-heading">
        Update Students
    </div>
    <div class="form-panel">
        <form action="updatadatastud.php" method="post" enctype="multipart/form-data">
            <table>
                <tr>
                    <td class="label">Name:</td>
                    <td><input type="text" name="name" class="inp" value="<?php echo $data['name']; ?>" required /></td>
                </tr>
                <tr class="label">
                    <td>Roll No:</td>
                    <td><input type="number" name="roll" class="inp" value="<?php echo $data['rollno']; ?>" required /></td>
                </tr>
                <tr class="label">
                    <td>Class:</td>
                    <td><input type="name" name="class" class="inp" value="<?php echo $data['class']; ?>" required /></td>
                </tr>
                <tr class="label">
                    <td>Mobile No:</td>
                    <td><input type="text" name="contact" class="inp" value="<?php echo $data['contact']; ?>" required /></td>
                </tr>
                <tr class="label">
                    <td>City:</td>
                    <td><input type="text" name="city" class="inp" value="<?php echo $data['city']; ?>" required /></td>
                </tr>
                <tr class="label">
                    <td>Image:</td>
                    <td><input type="file" name="img" required /></td>
                </tr>
                <tr>

                    <td>
                        <input type="hidden" name="sid" value="<?php echo $data['studentid']; ?>">
                        <input type="submit" value="Submit" name="submit" class="button">
                    </td>
                    <td><input type="reset" value="Reset" name="reset" class="button"></td>
                </tr>
            </table>
        </form>
    </div>
</body>

</html>