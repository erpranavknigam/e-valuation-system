<?php
session_start();

if (isset($_SESSION['uid'])) {
    echo "";
} else {
    header('location:adminlogin.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="adminstyle.css" type="text/css">
    <link href="https://fonts.googleapis.com/css2?family=Acme&family=Fredoka+One&family=Patua+One&family=Righteous&display=swap" rel="stylesheet">
    <title>Admin|Add Student</title>
</head>

<body>
    <div class="backtodash" style="font-size:18px;
    font-weight:bolder;
    font-family:'Righteous',cursive;
    background-color:#f29f3d;
    width:100px;
    text-align:center;"><a href="admindash.php" style="text-decoration: none;color:white;"> Dashboard</a></div>
    <div class="cplogout">
        <a href="adminlogout.php">logout</a>
    </div>
    <div class="cpheading">
        Admin Control Panel
    </div>
    <div class="page-heading">
        Add Students
    </div>

    <div class="form-panel">
        <form action="addstudent.php" method="post" enctype="multipart/form-data">
            <table>
                <tr>
                    <td class="label">Name:</td>
                    <td><input type="text" name="name" class="inp" placeholder="Enter Full Name" required /></td>
                </tr>
                <tr class="label">
                    <td>Roll No:</td>
                    <td><input type="number" name="roll" class="inp" placeholder="Enter Roll No" required /></td>
                </tr>
                <tr class="label">
                    <td>Class:</td>
                    <td><input type="name" name="class" class="inp" placeholder="Enter Class" required /></td>
                </tr>
                <tr class="label">
                    <td>Mobile No:</td>
                    <td><input type="text" name="contact" class="inp" placeholder="Enter Mobile Number" required /></td>
                </tr>
                <tr class="label">
                    <td>City:</td>
                    <td><input type="text" name="city" class="inp" placeholder="Enter City" required /></td>
                </tr>
                <tr class="label">
                    <td>Image:</td>
                    <td><input type="file" name="simg" required /></td>
                </tr>
                <tr class="label">
                    <td>Subject1:</td>
                    <td><input type="file" name="sub1" required /></td>
                </tr>
                <tr class="label">
                    <td>Subject2:</td>
                    <td><input type="file" name="sub2" required /></td>
                </tr>
                <tr class="label">
                    <td>Subject3:</td>
                    <td><input type="file" name="sub3" required /></td>
                </tr>
                <tr class="label">
                    <td>Subject4:</td>
                    <td><input type="file" name="sub4" required /></td>
                </tr>
                <tr class="label">
                    <td>Subject5:</td>
                    <td><input type="file" name="sub5" required /></td>
                </tr>
                <tr>
                    <td><input type="submit" value="Submit" name="submit" class="button"></td>
                    <td><input type="reset" value="Reset" name="reset" class="button"></td>
                </tr>
            </table>
        </form>
    </div>
</body>

</html>
<?php
function newId()
{
    $s = md5(uniqid("stu", time()));
    $newss = substr($s, 0, 8);
    return $newss;
}
function newPass() {
    $pass = md5(uniqid("pas",time()));
    $newpass = substr($pass,0,5);
    return $newpass;
}
if (isset($_POST['submit'])) {
    include('../dbcon.php');

    $name = strtolower($_POST['name']);
    $rollno = $_POST['roll'];
    $class = $_POST['class'];
    $mobile = $_POST['contact'];
    $city = strtolower($_POST['city']);
    
    $imagename = $_FILES['simg']['name'];
    $tempname = $_FILES['simg']['tmp_name'];
    $sub1name = $_FILES['sub1']['name'];
    $sub1tempname = $_FILES['sub1']['tmp_name'];
    $sub2name = $_FILES['sub2']['name'];
    $sub2tempname = $_FILES['sub2']['tmp_name'];
    $sub3name = $_FILES['sub3']['name'];
    $sub3tempname = $_FILES['sub3']['tmp_name'];
    $sub4name = $_FILES['sub4']['name'];
    $sub4tempname = $_FILES['sub4']['tmp_name'];
    $sub5name = $_FILES['sub5']['name'];
    $sub5tempname = $_FILES['sub5']['tmp_name'];
    $stuid = newId();
    $pwd = newPass();
    // echo $tempname;
    // // echo $nameoffile;
    copy($tempname,"../dataimg/student/$imagename");
    move_uploaded_file($sub1tempname, "../files/hindi/$sub1name");
    move_uploaded_file($sub2tempname, "../files/english/$sub2name");
    move_uploaded_file($sub3tempname, "../files/math/$sub3name");
    move_uploaded_file($sub4tempname, "../files/physics/$sub4name");
    move_uploaded_file($sub5tempname, "../files/chemistry/$sub5name");

    // if(move_uploaded_file($tempname,"../dataimg/student/$imagename")){
    //     echo "";
    // } else{
    //     echo "Image not uploaded";
    //     exit;
    // }

    $qry = "INSERT INTO `student`(`studentid`, `name`, `class`, `image`, `city`, `contact`, `rollno`, `password`, `hindi`, `english`, `math`, `physics`, `chemistry`) 
            VALUES ('$stuid','$name','$class','$imagename','$city','$mobile','$rollno','$pwd','$sub1name','$sub2name','$sub3name','$sub4name','$sub5name')";

    $run = mysqli_query($con, $qry);

    if ($run == True) {
?>
        <script>
            alert("Data Inserted successfully");
        </script>
<?php
    } else {
        echo "Error: " . $run . "<br>" . mysqli_error($con);
    }
}
?>