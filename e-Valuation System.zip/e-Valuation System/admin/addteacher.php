<?php
session_start();

if (isset($_SESSION['uid'])) {
    echo "";
} else {
    header('location:adminlogin.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="adminstyle.css" type="text/css">
    <link href="https://fonts.googleapis.com/css2?family=Acme&family=Fredoka+One&family=Patua+One&family=Righteous&display=swap" rel="stylesheet">
    <title>Admin|Add Teacher</title>
</head>

<body>
    <div class="backtodash" style="font-size:18px;
    font-weight:bolder;
    font-family:'Righteous',cursive;
    background-color:#f29f3d;
    width:100px;
    text-align:center;"><a href="admindash.php" style="text-decoration: none;color:white;"> Dashboard</a></div>
    <div class="cplogout">
        <a href="adminlogout.php">logout</a>
    </div>
    <div class="cpheading">
        Admin Control Panel
    </div>
    <div class="page-heading">
        Add Teachers
    </div>

    <div class="form-panel">
        <form action="addteacher.php" method="post" enctype="multipart/form-data">
            <table>
                <tr>
                    <td class="label">Name:</td>
                    <td><input type="text" name="name" class="inp" placeholder="Enter Full Name" required /></td>
                </tr>
                <tr>
                    <td class="label">Subject:</td>
                    <td><input type="text" name="sub" class="inp" placeholder="Enter Subject Taught" required /></td>
                </tr>
                <tr class="label">
                    <td>Mobile No:</td>
                    <td><input type="text" name="contact" class="inp" placeholder="Enter Mobile Number" required /></td>
                </tr>
                <tr class="label">
                    <td>City:</td>
                    <td><input type="text" name="city" class="inp" placeholder="Enter City" required /></td>
                </tr>
                <tr class="label">
                    <td>Image:</td>
                    <td><input type="file" name="img" required /></td>
                </tr>
                <tr>
                    <td><input type="submit" value="Submit" name="submit" class="button"></td>
                    <td><input type="reset" value="Reset" name="reset" class="button"></td>
                </tr>
            </table>
        </form>
    </div>
</body>

</html>
<?php
function tecnewId()
{
    $s = md5(uniqid("tec", time()));
    $newss = substr($s, 0, 10);
    return $newss;
}
function passgen()
{
    $pass = md5(uniqid("tecpass", time()));
    $newpass = substr($pass, 0, 5);
    return $newpass;
}
if (isset($_POST['submit'])) {
    include('../dbcon.php');

    $name = strtolower($_POST['name']);
    $subject = $_POST['sub'];
    $mobile = $_POST['contact'];
    $city = strtolower($_POST['city']);
    $imagename = $_FILES['img']['name'];
    $tempname = $_FILES['img']['tmp_name'];
    $tecid = tecnewId();
    $tecpass = passgen();

    // echo $tempname;
    // // echo $nameoffile;
    copy($tempname,"../dataimg/teacher/$imagename");
    // if(copy($_FILES['img']['tmp_name'],"../dataimg/teacher/$imagename")){
    //     echo "";
    // } else{
    //     echo "Image not uploaded";
    //     exit;
    // } 

    $qry = "INSERT INTO `teacher`(`teacherid`, `teachername`, `subject`, `password`, `mobile`, `city`, `image`) VALUES ('$tecid','$name','$subject','$tecpass','$mobile','$city','$imagename')";

    $run = mysqli_query($con, $qry);

    if ($run == True) {
?>
        <script>
            alert("Data Inserted successfully");
        </script>
<?php
    } else {
        echo "Error: " . $run . "<br>" . mysqli_error($con);
    }
}
?>