<?php
session_start();
if (isset($_SESSION['uid'])) {
    header('location:admindash.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../css/style.css" type="text/css">
    <link href="https://fonts.googleapis.com/css2?family=Acme&family=Fredoka+One&family=Patua+One&family=Righteous&display=swap" rel="stylesheet">
    <title>Admin Login Panel</title>
</head>

<body>
    <p class="heading">Admin Login</p>
    <div class="panel">
        <div class="left-panel">
            <div class="image">
                <img src="../image/2.png" alt="user" srcset="" width="100px">
            </div>
            <div class="title">
                Admin Login
            </div>
        </div>
        <div class="right-panel">
            <div class="form">
                <form action="adminlogin.php" method="post">
                    <input type="text" name="uname" id="uid" placeholder="Enter Username" required />
                    <input type="password" name="password" id="pwd" placeholder="Enter Password" required />
                    <input type="submit" value="login" name="login" class="submit-button" />
                </form>
            </div>
        </div>
    </div>
</body>

</html>
<?php
include('../dbcon.php');
if (isset($_POST['login'])) {
    $username = $_POST['uname'];
    $password = $_POST['password'];

    $qry = "SELECT * FROM `admin` WHERE `username` = '$username' AND `password` = '$password'";
    $run = mysqli_query($con, $qry);

    $row = mysqli_num_rows($run);
    if ($row < 1) {
?>
        <script>
            alert("User does not exists.")
            window.open('adminlogin.php', '_self');
        </script>
<?php
    } else {
        $data = mysqli_fetch_assoc($run);

        $id = $data['id'];

        $_SESSION['uname'] = $username;
        $_SESSION['uid'] = $id;
        header('location:admindash.php');
    }
}
?>