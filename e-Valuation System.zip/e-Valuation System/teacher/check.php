<?php
session_start();
require 'config.php';

?>
<?php
require 'config.php';
$un=$_SESSION['username'];
$query="SELECT `teachername`,`subject`,`image` FROM `teacher` WHERE `teacherid`='$un'";
$result = mysqli_query($con,$query);
  if (!$result)
  {
      echo 'could not run query:';
      exit;
  }
  $row= mysqli_fetch_row($result);
?>
<!DOCTYPE html>
<html lang="en_US">
<head>
<meta charset="UTF-8">
<title>Welcome</title>
<link rel="stylesheet" href="css/check.css" type="text/css">
</head>
<body style="background-color: pink;">
<div class="teachertitle" align="center">
<a href="../index.php">
<input name="logout" type="submit" id="logout_btn" value="logout" style='float:right'; >
</a>
<h1>Welcome to teacher dashboard</h1>
</div>
<div class="teachername" style="margin-top:30px">
<img src="../dataimg/teacher/<?php echo $row[2];?>" style="width:150px;height:150px; float:left; border-radius:50%;margin-top:-10px;"/>
<h3>Teacher id: <?php echo $un;?></h3>
<h3>Name of teacher: <?php echo $row[0];?></h3>
<h3>Subject: <?php echo $row[1];?></h3>
</div>
<div>
    <?php
        $tecid = $_GET['tecid'];
        $sub = $_GET['subject'];
        $studid = $_GET['studid'];
        echo "<h1 class='studentid' style='text-align:center;font-family:cursive;color:#530602;text-decoration:underline overline;'>Student id: ".$studid."</h1>"; 
    ?>
</div>
<?php
    $q = "SELECT `studentid`, `teacherid`, `filename` FROM `files` WHERE `studentid`='$studid' AND `teacherid`='$tecid'";
    $r = mysqli_query($con,$q);
    $re = mysqli_fetch_array($r);
    $file = $re[2];
    

    
?>
<div class="iframe" style="display: inline-block;width:80%;">
    
    <iframe src="<?php echo "../files/$sub/$file" ?>" title="Copy of Student <?php echo $studid;?>" width="80%" height="600px"></iframe>
    
</div>
<div class="marksform" style="display:inline-block;margin-right:25px;border:5px double;height:auto;width:17%;text-align:center;border-radius:20px;">
  <form action="" method="post"> 
    Question 1: &nbsp;&nbsp;<input type='number' name='q1' style='width:30px;margin-top:10px;'><br/><br/>
    Question 2: &nbsp;&nbsp;<input type='number' name='q2' style='width:30px;margin-top:10px;'><br/><br/>
    Question 3: &nbsp;&nbsp;<input type='number' name='q3' style='width:30px;margin-top:10px;'><br/><br/>
    Question 4: &nbsp;&nbsp;<input type='number' name='q4' style='width:30px;margin-top:10px;'><br/><br/>
    Question 5: &nbsp;&nbsp;<input type='number' name='q5' style='width:30px;margin-top:10px;'><br/><br/>
    Question 6: &nbsp;&nbsp;<input type='number' name='q6' style='width:30px;margin-top:10px;'><br/><br/>
    Question 7: &nbsp;&nbsp;<input type='number' name='q7' style='width:30px;margin-top:10px;'><br/><br/>
    Question 8: &nbsp;&nbsp;<input type='number' name='q8' style='width:30px;margin-top:10px;'><br/><br/>
    Question 9: &nbsp;&nbsp;<input type='number' name='q9' style='width:30px;margin-top:10px;'><br/><br/>
    Question 10: &nbsp;&nbsp;<input type='number' name='q10' style='width:30px;margin-top:10px;'><br/><br/>
    <input type="submit" value="Submit" class="submitbutton" name="submit">
  </form>
    
</div>
<?php
    if(isset($_POST['submit'])){
        $question1 = $_POST['q1'];
        $question2 = $_POST['q2'];
        $question3 = $_POST['q3'];
        $question4 = $_POST['q4'];
        $question5 = $_POST['q5'];
        $question6 = $_POST['q6'];
        $question7 = $_POST['q7'];
        $question8 = $_POST['q8'];
        $question9 = $_POST['q9'];
        $question10 = $_POST['q10'];
        $total = $question1+$question2+$question3+$question4+$question5+$question6+$question7+$question8+$question9+$question10;
        
        $qr = "UPDATE `marks` SET `$sub` = '$total' WHERE `studentid` = '$studid'";
        mysqli_query($con,$qr); 
        exit;
    }
?>
</body>
</html>