<?php
session_start();
require 'config.php';

?>
<?php
require 'config.php';
$un=$_SESSION['username'];
$query=("SELECT `teachername`,`subject`,`image` FROM `teacher` WHERE `teacherid`='$un'");
$result = mysqli_query($con,$query);
  if (!$result)
  {
      echo 'could not run query:';
      exit;
  }
  $row= mysqli_fetch_row($result);
?>
<!DOCTYPE html>
<html lang="en_US">
<head>
<meta charset="UTF-8">
<title>Welcome</title>
<link rel="stylesheet" href="css/style1.css" >
</head>
<body style="background-color: pink;">
<div class="teachertitle" align="center">
<a href="../index.php">
<input name="logout" type="submit" id="logout_btn" value="logout" style='float:right'; >
</a>
<h1>Welcome to teacher dashboard</h1>
</div>
<div class="teachername" style="margin-top:30px">
<img src="../dataimg/teacher/<?php echo $row[2];?>" style="width:150px;height:150px; float:left; border-radius:50%;margin-top:-10px;"/>
<h3>Teacher id: <?php echo $un;?></h3>
<h3>Name of teacher: <?php echo $row[0];?></h3>
<h3>Subject: <?php echo $row[1];?></h3>
</div>
<div class="dashboard">
<?php
 require 'config.php';
 $qry="SELECT `studentid`,`filename` FROM `files` WHERE `teacherid`='$un'";
 $myresult=mysqli_query($con,$qry);
 $count=1;
 $sub = $row[1];
echo
"<table border=1 style='width:100%;font-size:15px;margin-top:30px;' align='center'>
<tr>
<th>S.No.</th>
<th>Student id</th>
<th>File</th>
<th>Total marks</th>
<th>Obtained</th>
</tr>";
while($row = mysqli_fetch_array($myresult))
{ 
  $stdid=$row['studentid'];
  $qr = "SELECT `$sub` FROM `marks` WHERE `studentid` = '$stdid'";
  $mr = mysqli_query($con,$qr);
  $r = mysqli_fetch_array($mr);
  $marks = $r[0];
  $q = "INSERT INTO `marks`(`studentid`) VALUES ('$stdid')";
mysqli_query($con,$q);
     echo "<tr style='text-align:center;'>";
     echo "<td>".$count."</td>";
     echo "<td ><a href='check.php?studid=$stdid&tecid=$un&subject=$sub'>".$row['studentid']."</a></td>";
     echo "<td>".$row['filename']."</td>";
     echo "<td>100</td>";
     echo  "<td><input type='text' name='marks' value = '$marks' style='width:30px; text-align:center;display:block;margin-left:auto;margin-right:auto;' disabled></td>";
     echo "</tr>";
     $count++;
     
}
echo "</table>";

?>

</div>

</body>
</html>
