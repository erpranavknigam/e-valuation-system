<?php
 session_start();
 require 'config.php';
 
?>
<!DOCTYPE html>
<html>
<head>
<title>Teacher login</title>
<link rel="stylesheet" href="css/style.css">
</head>
<script>
   window.alert("Download the pdf viewer plugin for browser before logging in.");
   window.alert("URL: chrome.google.com/webstore/detail/pdf-viewer/oemmndcbldboiebfnladdacbdfmadadm?hl=en");
</script>
<body style="background-color:#487eb0">
  <div class = "login-panel"> 
   <div id="main-wrapper">
  <center>
  <h2>Teacher login</h2>
  <img src="imgs/avatar.jpeg" class="avatar"/>
  </center>
  
   <form class="myform" action="teacherlogin.php" method="post">
   <lable><b>Enter Username:</lable><br>
   <input name="username" type="text" class="inputvalues" placeholder="Type your username" required/><br><br>
   <lable><b>Enter Password:</lable><br>
   <input name="password" type="password" class="inputvalues" placeholder="Type your password" required/><br><br>
   <input name="login" type="submit" id="login_btn" value="login"/>

</form>
</div>
<?php
 if(isset($_POST['login']))
{    $username=$_POST['username'];
     $password=$_POST['password'];
    $query="select * from teacher where teacherid='$username' AND password='$password'";
    $query_run = mysqli_query($con,$query);
    
    if(mysqli_num_rows($query_run) > 0)
    {
       $_SESSION['username']=$username;
       header('location:teacherdash.php');
    }
    else 
    {
       echo '<script type="text/javascript">alert("Invalid username or password")</script>';
    }
}


?>

   </div>
</body>
</html>




