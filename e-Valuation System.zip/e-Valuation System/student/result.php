<?php
session_start();

if (isset($_SESSION['uid'])) {
    echo "";
} else {
    header('location:information.php');
}
?>
<?php
    
    include('../dbcon.php');
    $student = $_GET['studid'];
    $studid = $_SESSION['studuser'];
    $query = "SELECT * FROM `marks` WHERE `studentid` = '$student'";
    $result = mysqli_query($con,$query);
    if (!$result) {
        echo 'Could not run query: ' . mysqli_error($result);
        exit;
    }
    $row = mysqli_fetch_row($result);
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="studentstyle1.css" type="text/css">
</head>
<body>
    <h1 class="resulthead">Result</h1>
    <table class="tableofresult" style="width:100%;" border="1px">
        <tr class="tablerow">
            <th>Subject</th>
            <th>Total</th>
            <th>Obtained</th>
        </tr>
        <tr class="tablerow">
            <td>Hindi</td>
            <td>100</td>
            <td><?php echo $row[1];?></td>
        </tr>
        <tr class="tablerow">
            <td>English</td>
            <td>100</td>
            <td><?php echo $row[2];?></td>
        </tr>
        <tr class="tablerow">
            <td>Physics</td>
            <td>100</td>
            <td><?php echo $row[3];?></td>
        </tr>
        <tr class="tablerow">
            <td>Chemistry</td>
            <td>100</td>
            <td><?php echo $row[4];?></td>
        </tr>
        <tr class="tablerow">
            <td>Math</td>
            <td>100</td>
            <td><?php echo $row[5];?></td>
        </tr>
        
    </table>
    <div class="resultstatus">
    <h2 class="result">Total Marks: 500</h2>
    <h2 class="result">Obtained: <?php print($row[1]+$row[2]+$row[3]+$row[4]+$row[5]); ?></h2>
    <h2 class="result">Percentage: <?php $total = $row[1]+$row[2]+$row[3]+$row[4]+$row[5]; $percentage = $total/5; echo $percentage;?></h2>
    <?php
        if($percentage > 75) {
            $status = "Distinction";
        } else if($percentage < 75 && $percentage > 60){
            $status = "1st Division";
        } else if($percentage < 60 && $percentage > 50) {
            $status = "2nd Division";
        } else if($percentage < 50 && $percentage > 33) {
            $status = "3rd Division";
        } else{
            $status = "Fail";
        }
    ?>
     <h2 class="result">Status: <?php echo $status;?></h2>
    </div>

    <input type="button" value="Print" onclick="window.print();" class="printbutton"/>

</body>
</html>