<?php
session_start();
if (isset($_SESSION['uid'])) {
    header('location:information.php');
}
?>
 <!doctype html>  
<html>  
<head>  
<title>Login</title> 
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css"> <link href="https://fonts.googleapis.com/css? family=Ubuntu" rel="stylesheet">
<style>
</style>
</head>  
<body>  
<h1>STUDENT LOGIN PANEL</h1>
   <div class="login">
    <h2>Login</h2>
    <form method="post">
        <input type="text" name="u" placeholder="Username" id="uid" required="required" />
        <input type="password" name="p" placeholder="Password" required="required" />
        <input type="submit" class="btn btn-primary btn-block btn-large" value="login"/>
    </form>
</div>

<?php  
include('../dbcon.php');
if(isset($_POST["submit"])){  
  
if(!empty($_POST['u']) && !empty($_POST['p'])) {  
    $user=$_POST['u'];  
    $pass=$_POST['p'];  
  
    $con=mysqli_connect('localhost','root','','minor') or die(mysqli_error($qry));  
    // mysqli_select_db($con,'minor') or die("cannot select DB");  
    $qry = "SELECT * FROM `student` WHERE `studentid` = '$user' AND `password` = '$pass'";
    $query=mysqli_query($con,$qry);  
    $numrows=mysqli_num_rows($query);  
    if($numrows >= 1)  
    {  
    while($row=mysqli_fetch_assoc($query))  
    {  
    $dbusername=$data['studentid'];  
    $dbpassword=$data['password']; 
      $image=$data['image'];
      
      $class=$data['class'];
     
      $rollnum=$data['rollno'];
      $contact=$data['contact'];
      $address=$data['city'];
    }  
    if($user == $dbusername && $pass == $dbpassword)  
    {   
           $_SESSION['sess_user']=$user;
           $_SESSION['sess_image']=$image;
             
           $_SESSION['sess_class']=$class;         
           
           $_SESSION['sess_rollnum']=$rollnum;
           $_SESSION['sess_contact']=$contact;
           $_SESSION['sess_address']=$address;
           $_SESSION['uid'] = $dbusername;
    /* Redirect browser */  
    header("location: information.php");  
    }  
    } else {  
    echo "Invalid username or password!";  
    }  
} else {  
    echo "All fields are required!";  
}  
}  
?>   
</body>  
</html>   