<?php
session_start();

if (isset($_SESSION['uid'])) {
    echo "";
} else {
    header('location:studentlogin.php');
}
?>
<?php
    include('../dbcon.php');
    $studid = $_SESSION['studuser'];
    $query = "SELECT `name`,`rollno`,`image`,`class` FROM `student` WHERE `studentid` = '$studid'";
    $result = mysqli_query($con,$query);
    if (!$result) {
        echo 'Could not run query: ' . mysqli_error($result);
        exit;
    }
    $row = mysqli_fetch_row($result);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../admin/adminstyle.css" type="text/css">
    <link rel="stylesheet" href="studentstyle.css" type="text/css">
    <link href="https://fonts.googleapis.com/css2?family=Acme&family=Fredoka+One&family=Patua+One&family=Righteous&display=swap" rel="stylesheet">
    <title>Student Dashboard</title>
</head>

<body>

    <div class="cplogout">
        <a href="studentlogout.php">logout</a>
    </div>
    <div class="cpheading">
        Student Dashboard
    </div>
    <div>
        <div class="welcome"><?php echo "Welcome \"" .$row[0]. "\""; ?></div>
        <div class="detailbody">
            <div class="stdimg"><img src="../dataimg/student/<?php echo $row[2];?>"/></div>
            <div class="studetail">
                <div class="stdname"><?php echo "Name: ".$row[0]; ?></div>
                <div class="stdroll"><?php echo "Roll Number: ".$row[1]; ?></div>
                <div class="stdclass"><?php echo "Class: ".$row[3];?></div>
            </div>
        </div>
    </div>
    <div class="resultbutton">
        <?php 
            // $studentid = $_SESSION['studuser'];
            echo "<a href=\"result.php?studid=$studid\">Your Result</a>"
        ?>
        
    </div>
</body>

</html>