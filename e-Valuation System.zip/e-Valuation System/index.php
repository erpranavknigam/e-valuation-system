<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/indexstyle.css" type="text/css">
    <link href="https://fonts.googleapis.com/css2?family=Acme&family=Fredoka+One&family=Patua+One&family=Righteous&display=swap" rel="stylesheet">
    <title>Valuation System</title>
</head>
<body>

    <div class = "heading">e - Valuation System</div>
    <div class="main">
    <div class="admin">
        <div class="img"><img src="image/2.png"/></div>
        <a href="admin/adminlogin.php"><div class="title">Admin Login</div></a>
    </div>
    <div class="teacher">
        <div class="img"><img src="image/teacher.png"/></div>
        <a href="teacher/teacherlogin.php"><div class="title">Teacher Login</div></a>
    </div>
    <div class="student">
        <div class="img"><img src="image/student.png"/></div>
        <a href="student/studentlogin.php"><div class="title">Student Login</div></a>
    </div>
    </div>
</body>
</html>