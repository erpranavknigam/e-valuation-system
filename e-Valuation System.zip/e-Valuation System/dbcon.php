<?php
   $con =  mysqli_connect('localhost','root','','minor');
    if($con==FALSE){
        echo "Connection is not done";
    }
    
?>